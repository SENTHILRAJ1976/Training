package tnq.co.in.JavaTraining;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the Number");
		
		int number = scan.nextInt();
		
while (number > 0) {
	System.out.print(number%10);
	number = number/10;
	
	scan.close();
}
		
		
		
		
		
	}

}
