package tnq.co.in.JavaTraining;

public class Pattern1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a,b,c=1;
		for (int i=1; i<=5; i++) {
			
			for (int j=1; i<=1; j++) {
				System.out.print(c+ "");
				c++;
				
			}
			System.out.println();
		}
		
		
	}

}
