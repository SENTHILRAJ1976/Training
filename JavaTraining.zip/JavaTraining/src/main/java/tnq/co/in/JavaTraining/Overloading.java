package tnq.co.in.JavaTraining;


class sample {

	int sampleMethod(){
		
		
	return 0;

	}
	
	int sampleMethod(int x){
		
		
		return x;

		}
	float sampleMethod(float x){
		
		
		return x;

		}
	double sampleMethod(double x){
		
		
		return x;

		}
	String sampleMethod(String x){
		
		
		return x;

		}
	
	
}






public class Overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		sample s = new sample();
		System.out.println(s.sampleMethod());
		System.out.println(s.sampleMethod(10));
		System.out.println(s.sampleMethod(10.2f));
		System.out.println(s.sampleMethod(10.22));
		System.out.println(s.sampleMethod("Senthil"));
		
		
		
	}

}
