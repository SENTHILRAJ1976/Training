package tnq.co.in.JavaTraining;

import java.util.Scanner;

public class Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//System.out.println("1");
		/*System.out.println("222");
		System.out.println("33333");*/
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the Number");
		
		int number = scan.nextInt();
		
		int temp = 1;
		
		//int temp2 = 1;
		//boolean isPrime = true;
		for(int i=1; i<=number; i++) {
			
			for(int j=1; j<=temp; j++) {
				
				if(i%2!=0) {
			
					System.out.print(i);
					
					
				}
				
				temp = temp+2;
				
						System.out.println();
			
			scan.close();
					
					
				}
				
				
		}
		
		
		
		
	}

}
