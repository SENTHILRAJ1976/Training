package tnq.co.in.JavaTraining;

import java.util.Scanner;

public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner (System.in);
		
		System.out.println("Enter the Number");
		
		int number = scan.nextInt();
		
		int right = 0;
		int left = 1;
		int Ans;
		
		System.out.println(right);
System.out.println(left);

		for (int i=2; i<=number; i++) {
			
			Ans = right + left;
			right = left;
			left = Ans;
			System.out.println(Ans);
	
			
			scan.close();
		}
		
	
	}

}
