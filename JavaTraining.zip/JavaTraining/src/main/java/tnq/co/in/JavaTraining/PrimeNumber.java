package tnq.co.in.JavaTraining;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the number");
		
		int number = scan.nextInt();
		
		
	
		int count = 0;
		
		for (int temp = number; temp>=1; temp--) {
			if (number%temp == 0) {
				
				count++;
				
			}
			
			
		}
			
		if (count == 2) {
			System.out.println("This is Prime Number");
		
		}
		else {
			System.out.println("This is not Prime Number");
		}
		
	}

}
