package tnq.co.in.JavaTraining;


class a1
{
	public static void display()
	{
		System.out.println("this is a display base");
	}
}
class b1 extends a1
{
	public static void display()
	{
		System.out.println("this is a display from derived");
	}
}
public class Overriding {

	public static void main(String[] args) 
	{
		b1.display();
		a1.display();
	}
}







