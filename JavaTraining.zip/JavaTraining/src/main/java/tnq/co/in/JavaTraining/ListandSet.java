package tnq.co.in.JavaTraining;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ListandSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> list1 = new ArrayList<String>();
	list1.add("A");
	list1.add("B");
	list1.add("C");
	list1.add("D");
	list1.add("E");
	list1.add("F");
	list1.add("G");
	list1.add("H");
	list1.add("I");
	list1.add("A");
	
System.out.println(list1);
	
	list1.remove(3);
	System.out.println(list1);
		
Set<Integer> set1 = new HashSet<Integer>();
set1.add(1);
set1.add(2);
set1.add(3);
set1.add(4);
set1.add(1);
set1.add(6);
set1.add(7);
set1.add(8);
set1.add(9);
set1.add(10);
	
System.out.println(set1);

set1.remove(4);
System.out.println(set1);
	}

}
