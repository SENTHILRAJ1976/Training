package tnq.co.in.JavaTraining;

class A{
	
	public void display1(int x) {
		
		System.out.println(x);
	}
	
}

class B extends A{
	
	public int Sum (int x, int y) {
		return x+y;
		
	}
	
}

class C extends B{
	
	public int Multiple (int x, int y) {
		return x*y;
	}
	
}



public class Inheritence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A a = new A();
		a.display1(5);
		B b = new B();
		b.display1(6);
		b.Sum(5, 6);
		C c = new C();
		c.display1(8);
		c.Sum(6, 9);
		c.Multiple(3, 7);
		
		
	}

}
