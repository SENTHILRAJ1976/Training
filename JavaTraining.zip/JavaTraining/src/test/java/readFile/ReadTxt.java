package readFile;

import java.io.File;
import java.util.Scanner;

public class ReadTxt {

	public static void main(String[] args) throws Exception {

		File file = new File("C:\\Users\\0177.TNQDC\\git\\repository\\TestLeaf\\Selinum\\sen.txt");

		Scanner sc = new Scanner(file);

		while (sc.hasNextLine())
			System.out.println(sc.nextLine());

		sc.close();

	}

}
