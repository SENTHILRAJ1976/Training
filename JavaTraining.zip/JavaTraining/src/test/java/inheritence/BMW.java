package inheritence;

public class BMW extends Car {

	
	public void safety() {
		System.out.println("SafestCar");
		
	}
	
	public void sophes() {
	System.out.println("Sophesticated");	
	}
}
