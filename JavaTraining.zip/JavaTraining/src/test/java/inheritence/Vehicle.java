package inheritence;

public class Vehicle {

	public void engine() {
		System.out.println("Vehicle - Engine");
		
	}
	
	
}
