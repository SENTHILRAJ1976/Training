package inheritence;

public class CarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BMW b = new BMW();
		b.engine();
		b.safety();
		b.sophes();
		
		Car c = new Car();
		c.start();
		c.stop();
		c.horn();
		
		Car c1 = new BMW();
		c1.engine();
		c1.start();
		c1.stop();
	}

}
