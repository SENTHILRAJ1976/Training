package inheritence;

public class Car extends Vehicle {

	public void start() {
		System.out.println("Car - start");
	
	}

	
	public void stop() {
		System.out.println("Car - stop");
	}
	
	public void horn() {
		System.out.println("Car- horn");
		
	}
}
