
public class Calc {

	static int a = 12;
	static int b = 15;
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Calculator cal = new Calculator();
	
		
		
		
	}

}
