package wdMethods;

public class WdMethods {

}
