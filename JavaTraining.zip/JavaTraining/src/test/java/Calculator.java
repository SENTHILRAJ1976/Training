
public class Calculator {


	static int a = 12;
	static int b = 15;
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Calculator calc = new Calculator();
	
	calc.sum();
	
	calc.sum1(a+b);

	}


}

