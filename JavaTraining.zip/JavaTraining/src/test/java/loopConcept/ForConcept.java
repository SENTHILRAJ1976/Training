package loopConcept;

public class ForConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		boolean status;
		status=true;
		
		boolean newstatus=false;
		
	System.out.println("The old boolean value was "+status);
	System.out.println("The new boolean value is "+newstatus);
	

		
		
		
	}

}
