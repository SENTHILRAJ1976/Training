package datatypeDemo;

public class VariableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		System.out.println("Loop Started");
		System.out.println("------------");
		
		for(int i=1;i<=20;i++)
		{
			System.out.println("I value is "+i);
			
			
		}		
		
		System.out.println("Loop Ended");
		
		}
	

}
