package datatypeDemo;

public class CreateAccount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte SlNo=1;
		String AccountHolderName="Rishitha";
		char AccountHolderInitial='S';
		String AccountType="Saving";
		long AccountNumber = 5331394442L;
		boolean IsAcvtive = true;
		float ROI = 8.5f;
		int MinBalance = 500;
		
		System.out.println(SlNo);
		System.out.println(AccountHolderName);
		System.out.println(AccountType);
		System.out.println(MinBalance);
		
		
	}

}
