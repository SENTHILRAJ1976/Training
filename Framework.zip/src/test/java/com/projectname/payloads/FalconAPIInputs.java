package com.projectname.payloads;

import java.util.HashMap;
import java.util.Map;

import com.projectname.basetest.APIMapper_New;

public class FalconAPIInputs extends APIMapper_New {
	
	protected static String accessToken = "af6c0b4abfcb11e8a5f40242ac1b0004";	
	
	public Map<String, String> headerAuthorization(){
		Map<String, String> headAuth = new HashMap<String, String>();
		headAuth.put("Authorization", "Token " + accessToken);	
		return headAuth;
	}
	
}
