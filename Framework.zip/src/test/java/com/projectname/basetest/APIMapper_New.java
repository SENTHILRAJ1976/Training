package com.projectname.basetest;

import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.projectname.base.BaseClass;
import com.projectname.utils.PropertyObjectReader;
import com.sun.mail.iap.ByteArray;

import io.restassured.RestAssured;
import io.restassured.response.Response;



public class APIMapper_New extends BaseClass{
	
	public static Logger log = LogManager.getLogger(APIMapper_New.class.getName());
	private String js;
	ObjectMapper mapper = new ObjectMapper();	
	public Response response;
	
	
	protected String getPostParameter;
	protected String getGetParameter;
	protected String getPutParameter;
	protected String getDeleteParameter;
	protected String pathPostParameterWithoutHeader;
	protected String pathPostParameterHeaderWithFile;
	protected String pathPostParameterWithHeader;
	protected String getPathParameter;
	protected String formAsBodyWithHeadersPathParameter;
	protected String deletePathParameter;
	
	/**
	 * 
	 * @param unformattedJson
	 * @return unformatted json object to formatted json object
	 * @description: this method used to generate pretty view json format to use the
	 *               extent report
	 * @author: S. Karunamoorthy
	 */

	
	public String falconAPIBase() {	
		if(BaseClass.environm.equalsIgnoreCase("qa"))
		{
		 RestAssured.baseURI =  "http://10.0.5.114:8083/index.php";	
		}
		 return  RestAssured.baseURI ;
	}	
	
	
	public String formattedJson(String unformattedJson) {
		try {
			
			JsonParser jsonParser = new JsonFactory().createJsonParser(unformattedJson);

			Object json = mapper.readValue(jsonParser, Object.class);
			js = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);

		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return js;

	}	
	

	/**
	 * @return Base Application URI
	 * @description: This method holds the base URI of the applicaton
	 * @author: S. Karunamoorthy
	 */
	
	public String userManagementbaseURI() {
		String baseUri="";
		try {
			baseUri = PropertyObjectReader.userManagement();
			log.info("Base application URI-->" + baseUri);
			
		} catch (Exception e)
		{				
			e.printStackTrace();
		}		
		return baseUri;		
	}
	
	

	/**
	 * @description: This method holds authorization key value of the application
	 * @return Headers Key and Value
	 * @author: S. Karunamoorthy
	 */
	public Map<String, String> getHeader() {
			Map<String, String> header = new HashMap<String, String>();
			header.put("x-api-key", "4SU3flGTMW9aYKCqWCa5b66DJeojcSq784o7AUmM");
			header.put("authorization", "Basic QWRtaW5pc3RyYXRvcjpzaGVyaWRhbmFkbWludGVzdGluZw==");
			log.info("Headers info--> " + header);
		return header;
	}
	
	/**
	 *  @return It is produce the dynamic values, ex: GE878DFd34370
	 */
	
	public static String getSaltString() {
        String saltStr = null;
		try {
			String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
			StringBuilder salt = new StringBuilder();
			Random rnd = new Random();
			while (salt.length() < 18) 
			{
			    int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			    salt.append(SALTCHARS.charAt(index));
			}
			saltStr = salt.toString();
			log.info("Publisher name--> " + saltStr);
			//test.log(Status.INFO, "Publisher name:  " + saltStr);
		} catch (Exception e) {
		
			e.printStackTrace();
		}
        return saltStr;
        

    }

	/**@return Without double quotes string
	 * @description: This method removes the double quotes string in startwith and
	 *               endwith of any string value
	 * @author: S. Karunamoorthy
	 */
	public String removeDoubleQuotes(String doubleQuoatedString) {
		return doubleQuoatedString.replaceAll("\"", "");
	}
	

	
	public Map<String, String> userCredentails() {
		Map<String, String> credentials = new HashMap<String, String>();
		credentials.put("username", "naresh.vodlamani@tnqsoftware.co.in");
		credentials.put("password", "test1234");
		log.info("Headers info--> " + credentials);
	return credentials;
}
	
	
	public Map<String, String> userCredentailsForUser2() {
		Map<String, String> credentials = new HashMap<String, String>();
		credentials.put("username", "karunamoorthys@tnqsoftware.co.in");
		credentials.put("password", "11");
		log.info("Headers info--> " + credentials);
	return credentials;
}
	
	public Map<String, String> userCredentailsAsSathesh() {
		Map<String, String> credentials = new HashMap<String, String>();
		credentials.put("username", "sathesh.murugesan@tnqsoftware.co.in");
		credentials.put("password", "test1234");
		log.info("Headers info--> " + credentials);
	return credentials;
}
	
	public Map<String, String> userWithoutCredentails() {
		Map<String, String> credentials = new HashMap<String, String>();
		credentials.put("username", "naresh.vodlamani@tnqsoftware.co.in");
		log.info("Headers info--> " + credentials);
	return credentials;
}
	
	public Map<String, String> userInvalidCredentails() {
		Map<String, String> credentials = new HashMap<String, String>();
		credentials.put("username", "naresh.vodlamani@tnqsoftware.co.in");
		credentials.put("password", "test12");
		log.info("Headers info--> " + credentials);
	return credentials;
}
	
	
	//Without Header  - Post Method
	public Response getPOSTUsingFormData(Map<String, String> inputForm , String pathPostParameterWithoutHeader) {	
		this.pathPostParameterWithoutHeader = pathPostParameterWithoutHeader;
		response = given().params(inputForm).when().post(pathPostParameterWithoutHeader);		
		System.out.println(response.asString());
		return response;
	}	
	
	
	// With form header along with "header as file" - Post Method
	public Response getPOSTUsingFormDataWithHeadersUsingFileUpload(Map<String, String> header, Map<String, Object> inputForm , String pathPostParameterHeaderWithFile, String fileUpload) {				
		this.pathPostParameterHeaderWithFile = pathPostParameterHeaderWithFile;	
		System.out.println("+++++++++++++++++++++++++");
		System.out.println(header);
		System.out.println(fileUpload);
		System.out.println(inputForm);
		System.out.println("+++++++++++++++++++++++++");
		Response resp =  given().headers(header).
			        multiPart("file", new File(fileUpload)).
			            formParam("file", fileUpload).
			            params(inputForm).when().post(pathPostParameterHeaderWithFile);		
		System.out.println(resp.asString());
		return resp;
	}
	
	
	
	
	// With form header - Post Method
	public Response getPOSTUsingFormDataWithHeaders(Map<String, String> header, Map<String, Object> inputForm , String pathPostParameterWithHeader) {	
		this.pathPostParameterWithHeader = pathPostParameterWithHeader;
		 Response resp =  given().headers(header).
		             params(inputForm).when().post(pathPostParameterWithHeader);		
		return resp;
	}
	
	// With body - Post Method
	public Response getPOSTUsingFormAsBodyWithHeaders(Map<String, String> header, String bodyData , String formAsBodyWithHeadersPathParameter) {		
		this.formAsBodyWithHeadersPathParameter = formAsBodyWithHeadersPathParameter;
		Response resp =  given().headers(header).body(bodyData).when().post(formAsBodyWithHeadersPathParameter);		
		return resp;
	}
	
	// Get Method
	public Response getGet(Map<String, String> header, String getPathParameter) {	
		this.getPathParameter = getPathParameter;
		Response resp = given().headers(header).when().get(getPathParameter);				
		return resp;		
	}
	
	// Get Method for download
	public byte[] getFileForDownload(Map<String, String> header, String getPathParameter) {	
		this.getPathParameter = getPathParameter;
		byte[] fileSize = given().headers(header).when().get(getPathParameter).asByteArray();				
		return fileSize;		
	}
	
	
	// With form header - Delete Method using Body
		public Response getDELETEUsingFormDataWithHeaders(Map<String, String> header, String bodyMessage , String deletePathParameter) {	
			this.deletePathParameter = deletePathParameter;
			 Response resp =  given().headers(header).
			             body(bodyMessage).when().delete(deletePathParameter);		
			return resp;
		}
		
		// With form header - Delete Method using Body
		public Response getDELETEUsingFormDataWithHeadersWithoutBody(Map<String, String> header, String deletePathParameter) {	
			this.deletePathParameter = deletePathParameter;
			System.out.println("coming");
			 Response resp =  given().headers(header).
			            when().delete(deletePathParameter);		
			 System.out.println(resp.asString());
			return resp;
		}
	
	
	

	/**
	 * @param bodyPayLoadJson
	 * @param pathParameter
	 * @return POST request
	 * @description: getPOST() method used to perform post request using path params and json payload 
	 * @author: S. Karunamoorthy
	 */
	public Response getPOST(String bodyPayLoadJson, String pathParameter) {
		
	this.getPostParameter = pathParameter;
		
		try {			
			
			response = given().params(userCredentails()).when().post(pathParameter);
	
		} catch (Exception e) {		
			e.printStackTrace();
		}

		return response;
	}

	/**
	 * 
	 * @param pathParameter
	 * @return GET request
	 * @description: getGET() method used to perform get request using path params 
	 * @author: S. Karunamoorthy
	 */
//	public Response getGET(String pathParameter) {
//		
//		this.getGetParameter = pathParameter;
//		
//		try {
//			response = given().headers(getHeader()).accept("application/json; charset=UTF-8").get(pathParameter);
//			
//			
//			log.info("GET request --> " +"path parameter: "+ pathParameter);
//			//test.log(Status.INFO, "GET request:  " + response);
//			} catch (Exception e) {		
//			e.printStackTrace();
//		}
//
//		return response;
//	}

	/**
	 * 
	 * @param bodyPayLoadJson
	 * @param pathParameter
	 * @return PUT request
	 * @description: getPUT() method used to perform put request using path params and json payload 
	 * @author: S. Karunamoorthy
	 */
	public Response getPUT(String bodyPayLoadJson, String pathParameter) {
		
		this.getPutParameter = pathParameter;
		
		try {
			response = given().headers(getHeader()).contentType("application/json; charset=UTF-8").body(bodyPayLoadJson)
					.when().put(pathParameter);
			
			
			log.info("PUT request --> " +"path parameter: "+ pathParameter +"payload json: "+ bodyPayLoadJson);
			//test.log(Status.INFO, "PUT request:  " + response);
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return response;
	}

	/**
	 * 
	 * @param pathParameter
	 * @return DELETE request
	 * @description: getDELETE() method used to perform delete request using path params 
	 * @author: S. Karunamoorthy
	 */
	public Response getDELETE(String pathParameter) {
		
		this.getDeleteParameter = pathParameter;
		
		try {
			response = given().headers(getHeader()).accept("application/json; charset=UTF-8").delete(pathParameter);
			
			
			log.info("DELETE request --> " +"path parameter: "+ pathParameter);
			//test.log(Status.INFO, "DELETE request:  " + response);
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return response;
	}
	
	//Falcon API
	public Response getPOSTUsingFileUpload(Map<String, String> header , String pathPostParameterHeaderWithFile, String fileUpload) {				
		this.pathPostParameterHeaderWithFile = pathPostParameterHeaderWithFile;	

		Response resp =  given().headers(header).
			        multiPart("file", new File(fileUpload)).
			           when().post(pathPostParameterHeaderWithFile);		
		System.out.println(resp.asString());
		return resp;
	}
	
	
	
	public Map<String, String> getAllResponseId(String idName, String IdValue) {
		Map<String, String> pushIds=null;
		try {
			pushIds = new HashMap<String, String>();
		pushIds.put(idName, IdValue);
	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return pushIds;
	}

}
