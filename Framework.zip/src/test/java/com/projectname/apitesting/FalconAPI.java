package com.projectname.apitesting;

import java.io.IOException;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.projectname.base.BasePage;
import com.projectname.files.FilesProvider;
import com.projectname.payloads.FalconAPIInputs;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import junit.framework.Assert;

public class FalconAPI extends FalconAPIInputs {
	
	int customerId = 695233;
	JsonPath jsonPathEvaluator;
	String uuidValue, fileUploadResp, statusResponse, responseConversion, conversionStatus;
	int responseTime;
	int responseCode;
	Response conversionResponse;
	
	static boolean conversionflag = false;
	static long start = 0;
	static long end = 0;


	@Test
	public void fileUpload() {

		try {
			falconAPIBase();					
			Response fileUpload = getPOSTUsingFileUpload(headerAuthorization(), "/ingest/fileupload/"+customerId+"", FilesProvider.Uploadfile);
			extentReportInformation("Request is Sent");
			System.out.println("File upload resp is" + fileUpload.asString());
			
			 jsonPathEvaluator = fileUpload.jsonPath();
			uuidValue = jsonPathEvaluator.get("uuid");
			System.out.println("Uuid " + uuidValue);
			
			extentReportInformation("Extracting an Access token");
			System.out.println("File resp is" + fileUpload.asString());
			extentReportPass("File upload is successfully done");

			responseTime = (int) fileUpload.getTime();
			responseCode = fileUpload.getStatusCode();
			fileUploadResp = fileUpload.asString();
			
			Assert.assertEquals(200, responseCode);

		} catch (Exception e) {
			System.out.println("Actual error of login is " + e.getMessage());
			Assert.fail();
		}

		finally {

			test.log(Status.PASS, "Request URI:  " + falconAPIBase() + pathPostParameterHeaderWithFile);
			test.log(Status.PASS, "Response time:  " + responseTime);
			BasePage.responsecodelog(200, responseCode);
			test.log(Status.PASS, "Response data: " + MarkupHelper.createCodeBlock((fileUploadResp)).getMarkup());

		}

	}
	
	

	}
