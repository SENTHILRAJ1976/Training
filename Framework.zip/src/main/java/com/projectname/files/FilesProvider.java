package com.projectname.files;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FilesProvider {
	
//	public static String extentReportFilePath="./reports/Neon_Automation_Testing_Report_"
//			+new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss").format(new Date()).replace(":", "-")+".html";
	public static String timeStamp = new SimpleDateFormat("ddMMyyyy").format(new Date());
	public static String extentReportFilePath="//tnqfs07/SOFTWARE/TESTING_SERVICES/Projects/Falcons/Api/Reports/ApiTestReport_"+timeStamp+".html";
//	public static String extentReportFilePath="./reports/Falcons_Automation_Testing_Report1.html";
	public static String extentReportConfiXMLFilePath="./src/main/resources/extent-config.xml";
	public static String configPropertyFilePath="./src/main/resources/config.properties";
	public static String testdataJsonFilePath="./src/test/resources/testdata.json";
//	public static String Uploadfile = "D:/01MyWorkspace/PgC-OnDemand-API/Input-Files/GoldenSet.zip";
//	public static String UploadInvalidfile = "D:/01MyWorkspace/PgC-OnDemand-API/Input-Files/Highlights.docx";
	public static String pdfFileValidation = "./Input-Files/pagination_dc4ct02.pdf";
	public static String htmlFileValidation = "./Input-Files/paginate_dc4ct02.html";
	public static String Uploadfile = "./Input-Files/falcon0002.zip";
	public static String UploadInvalidfile = "./Input-Files/Highlights.docx";
	
	
	
}
