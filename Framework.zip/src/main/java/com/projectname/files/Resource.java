package com.projectname.files;

public class Resource {	
	
	public static String pathParam = "/staging/publisher/" ;
}
